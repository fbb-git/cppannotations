#!/bin/bash

# Shell script to turn a PDF document into signatures, for binding into a book.
# First the pages a re reordered, then they are put 2-on-1-side-of-paper, 
# with the papersize double the original so the font stays the same size.
# 

MYNAME=$(basename $0)
VERSION='0.0.1'
VERBOSITY=1

NPRE=0 # nr of empty pages to prepend
NAPP=0 # nr of empty pages to append
SPS=5     # nr of sheets per signature (so the nr of pages in a signature is 4*$SPS)
EMPTYPAGE=empty.pdf
LOG=makebook.log

die()
{
    EC=${1}
    shift
    echo -e "Quitting because $@"
    echo "Extra output is in ${LOG}"
    exit ${EC}
}

say()
{
    VL=${1}
    shift
    [ "${VERBOSITY}" -ge ${VL} ] && echo -e "$@" | tee ${LOG}
}

usage()
{
cat <<EOF

 ${MYNAME} [options] <file>

 with <file> a PDF file
 and [options] any of

 -h --help        show this help and exit
 -V --version     show version and exit
 -q --quiet       show less output
 -v --verbose     show more output (more 'v' don't help)
 -d --debug       show debugging output
 -t <n>
 --thickness <n>  with <n> the thickness of the signatures in sheets of paper
                  (<n> may therefore be odd, as the signatures will form 4*<n>
                  pages when folded)
 -p <n>           prepend <n> empty pages before <file>
 --prepend <n>
 -a <n>           append <n> empty pages at the end of <file>
 --append <n>

EOF
exit 0
}

for EXECUTABLE in cat pdftk pdfinfo gs pdfbklt ; do
    FULLPATH=$(which ${EXECUTABLE})
    if test -z "${FULLPATH}" ; then
	die 13 "It looks like the needed program \"${EXECUTABLE}\" isn't available."
    fi
done


fillout()
{
    # $1 number of pages to prepend
    # $2 number of pages to append
    # $3 input filename
    # $4 output filename
    say 1 "Prepending and appending pages"
    TOCAT=""
    for (( i = 1 ; i <= ${1} ; i++ )) ; do
	TOCAT="${TOCAT} B1"
    done
    TOCAT="${TOCAT} A1-end"
    for (( i = 1 ; i <= ${2} ; i++ )) ; do
	TOCAT="${TOCAT} B1"
    done
    #echo "pdftk A=${3} B=${EMPTYPAGE} cat ${TOCAT} output ${4}"
    pdftk A=${3} B=${EMPTYPAGE} cat ${TOCAT} output ${4} > ${LOG} 2>&1
 
}

OPTARGS=$(getopt -n $0 -o 'hVqvdt:p:a:' --longoptions help,version,quiet,verbose,debug,thickness,prepend,append -- "$@")
eval set -- "$OPTARGS"
while (( "$#" > "0" )) ; do
    case "$1" in
        -h|--help )
            usage
            exit 0 ;;
        -V|--version )
            ${ECHO} ${MYNAME} ${VERSION}
            exit 0 ;;
        -q|--quiet )
            VERBOSITY=0
            shift;;
        -v|--verbose )
            VERBOSITY=2
            shift;;
        -d|--debug )
            set -x
            shift ;;
        -t|--thickness )
            SPS=${2}
            shift 2;;
        -p|--prepend )
            NPRE=${2}
            shift 2;;
        -a|--append )
	    NAPP=${2}
            shift 2;;
        -- )
            shift
            break;;
        *  )
            echo -e die 1 "option '${1}' unknown to ${MYNAME}\n"
            usage
            exit 1 ;;
    esac
done

INFILE=${1}

[ -n "${INFILE}" ] || usage

INBASE=$(basename ${INFILE} .pdf)
INFILLED="${INBASE}_filledout.pdf"
INLARGED="${INBASE}_filledout_enlarged.pdf"
OUTPUT="${INBASE}_book.pdf"

PPS=$(( 4 * ${SPS} )) # Calculate Pages Per Signature, 4 pages per sheet of paper
NPAGES=$(pdfinfo ${INFILE}|grep ^Pages|awk '{print $2}')

PAPERSIZE=$(pdfinfo ${INFILE}|grep '^Page size'|awk -F: '{print $2}'|sed 's/^.*(//g ; s/).*//g')
DOUBLESIZE=unknown
case ${PAPERSIZE} in
    'a1'|'A1' )
	DOUBLESIZE=A0 ;;
    'a2'|'A2' )
	DOUBLESIZE=A1 ;;
    'a3'|'A3' )
	DOUBLESIZE=A2 ;;
    'a4'|'A4'|'letter' )
	DOUBLESIZE=a3 ;;
    'a5'|'A5' )
	DOUBLESIZE=A4 ;;
    'a6'|'A6' )
	DOUBLESIZE=A5 ;;
    'a7'|'A7' )
	DOUBLESIZE=A6 ;;
    'a8'|'A8' )
	DOUBLESIZE=A7 ;;
    * )
	die "don't know how to double unknonw paper size ${PAPERSIZE}" ;;
esac


say 1 "Input PDF has ${NPAGES} pages"
say 1 "We will prepend ${NPRE} and append ${NAPP} pages"
say 1 "Signatures will be ${SPS} sheets, therefore ${PPS} pages"
say 1 "So the number of pages would total $(( ${NPAGES} + ${NPRE} + ${NAPP} ))"
if [ "$(( ( ${NPAGES} + ${NPRE} + ${NAPP} ) % ${PPS} ))" -ne 0  ] ; then
    say 1 "However, that is not a multiple of ${PPS}"
    NAPP=$(( ${NAPP} + ( ( 4 * ${SPS} ) - ( ( ${NPAGES} + ${NPRE} + ${NAPP} ) % ( 4 * ${SPS} ) ) ) ))
    say 1 "So in order to fill the number of pages out to a multiple of $(( 4 * ${SPS} )), we raised the number of pages to append to ${NAPP}"
    say 1 "So the total number of pages in the book now becomes $((${NPAGES} + ${NPRE} + ${NAPP} ))"
else
    say 1 "(That is a nice multiple of ${PPS})"
fi
[ $(( ( ${NPAGES} + ${NPRE} + ${NAPP} ) % ${PPS} )) -eq 0 ] || die 2 "calculated number of pages ($((${NPAGES} + ${NPRE} + ${NAPP} ))) is not a multiple of the signature size ($(( 4 * ${SPS})))"
NSIGN=$(( ( ${NPAGES} + ${NPRE} + ${NAPP} ) / ${PPS} ))
say 1 "That will be printed on $(( ( ${NPAGES} + ${NPRE} + ${NAPP} ) / 4 )) sheets of paper in ${NSIGN} signatures"

if [ "${NAPP}" -gt 0 ] || [ "${NPRE}" -gt 0 ] ; then
    say 1 "Generating an empty page to pre- and/or append"
    echo|gs -q -dNOPAUSE -dBATCH -sDEVICE=pdfwrite -sPAPERSIZE=$(echo ${PAPERSIZE}|tr 'A-Z' 'a-z') -dFIXEDMEDIA -dPDFFitPage -sOutputFile=${EMPTYPAGE}||die 3 "failed to generate an ampty page for appending and prepending"
fi

fillout ${NPRE} ${NAPP} ${INFILE} ${INFILLED}

say 1 "Enlarging document to ${DOUBLESIZE}"
#echo "gs -q -dNOPAUSE -dBATCH -sDEVICE=pdfwrite -sPAPERSIZE=${DOUBLESIZE} -dFIXEDMEDIA -dPDFFitPage -sOutputFile=${INLARGED} ${INFILLED}"
gs -q -dNOPAUSE -dBATCH -sDEVICE=pdfwrite -sPAPERSIZE=${DOUBLESIZE} -dFIXEDMEDIA -dPDFFitPage -sOutputFile=${INLARGED} ${INFILLED} >${LOG} 2>&1  || die 4 "failed to enlarge document to ${DOUBLESIZE}"

# Reorder pages and n-up them
SIGNATURES=''
say 1 "Splitting the document into signatures and putting them four-pages-on-a-sheet"
for (( i = 1 ; i <= ${NPAGES} ; i += ${PPS} )) ; do
    LP=$(( ${i} + ${PPS} - 1 ))
    SIGNATURE=signature_${i}-${LP}.pdf
    SIGNATURE_NUP=signature_${i}-${LP}_2x1.pdf
    if pdftk ${INLARGED} cat ${i}-${LP} output ${SIGNATURE} >${LOG} 2>&1 ; then
	[ "${VERBOSITY}" -gt 0 ] && echo -n '/'
    else
	die 5 "failed to create signature ${SIGN}: couldn't extract pages"
    fi
    if pdfbklt -2 ${SIGNATURE} >${LOG} 2>&1; then
	SIGNATURES="${SIGNATURES} ${SIGNATURE}"
	[ "${VERBOSITY}" -gt 0 ] && echo -n '\'
    else
	die 6 "failed to create signature ${SIGN}: couldn't reorder pages to booklet"
    fi
    #if pdfnup ${SIGNATURE} --nup 2x1 --outfile ${SIGNATURE_NUP} >${LOG} 2>&1 ; then
    #	SIGNATURES="${SIGNATURES} ${SIGNATURE_NUP}"
    #	[ "${VERBOSITY}" -gt 0 ] && echo -n _
    #else
    #	die 7 "failed to create signature ${SIGN}: couldn't 4-up"
    #fi
done
say 1 ''

# Output final doc
say 1 "Joining signatures into a single file"
if pdftk ${SIGNATURES} cat output ${OUTPUT} >${LOG} 2>&1 ; then
    say 1 "Your output is in ${OUTPUT}"
else
    die 6 "failed to join signatures into a single file"
fi
